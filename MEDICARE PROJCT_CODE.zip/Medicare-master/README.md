# Medicare

### Intention of Project

I want to put some public healthcare data in a format that allows people to make a more informed decision on where they decide to seek healthcare.  

A lot of information is out there - this one happens to be based off of Medicare data. I will add more to this readme as I get more time but for now - the shinyApp folder is my main focus.  

I created a sqlite database within there to improve speed and performance - I believe it's about 4 months old and could be updated.  

I would love some help with this so please submit whatever changes you would like to see. I haven't put very much time into it yet but will be doing so in early June (2017).

The application is available at https://stoltzmaniac.shinyapps.io/medicare_infections/
