package com.foodbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodboxSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
